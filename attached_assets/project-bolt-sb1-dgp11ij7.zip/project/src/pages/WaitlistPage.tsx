import React, { useState } from 'react';
import { supabase } from '../lib/supabase';

function WaitlistPage() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      const { error: supabaseError } = await supabase
        .from('waitlist')
        .insert([{ email }]);

      if (supabaseError) throw supabaseError;

      setSubmitted(true);
      setEmail('');
    } catch (err) {
      setError('Failed to join waitlist. Please try again.');
      console.error('Error:', err);
    }
  };

  return (
    <div className="min-h-screen bg-white relative overflow-hidden">
      {/* Checkered pattern background */}
      <div className="absolute inset-0">
        <div className="grid grid-cols-12 grid-rows-12 h-full">
          {[...Array(144)].map((_, i) => (
            <div
              key={i}
              className={`${
                (Math.floor(i / 12) + i % 12) % 2 === 0
                  ? 'bg-black/5'
                  : 'bg-white'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-screen px-4">
        <div className="max-w-md w-full bg-white/80 backdrop-blur-sm p-8 rounded-2xl shadow-2xl">
          <div className="flex justify-center mb-8">
            <img 
              src="https://imgur.com/a/2HGydzv" 
              alt="KLEDE"
              className="h-12"
            />
          </div>

          <p className="text-gray-600 text-center mb-8">
            Join the waitlist for exclusive access to our upcoming collection
          </p>

          {submitted ? (
            <div className="text-center text-green-600 font-medium">
              Thank you for joining our waitlist! We'll keep you updated.
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  required
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-black focus:border-transparent outline-none transition"
                />
              </div>
              {error && (
                <div className="text-red-500 text-sm text-center">{error}</div>
              )}
              <button
                type="submit"
                className="w-full bg-black text-white font-medium py-3 rounded-lg hover:bg-gray-900 transition duration-300"
              >
                Join Waitlist
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

export default WaitlistPage;